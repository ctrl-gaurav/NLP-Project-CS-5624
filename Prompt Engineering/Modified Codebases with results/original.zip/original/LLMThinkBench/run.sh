#!/bin/bash

# This script runs the llmthinkbench.cli command for a list of models sequentially.

# Common arguments for the llmthinkbench.cli command
# Ensure any arguments with spaces are properly handled if you modify this.
# For instance, if a task name had a space, you might need to quote it within this string
# or convert CMD_ARGS to an array. For the current arguments, this string is fine.
COMMON_ARGS="--tensor_parallel_size 1 \
--gpu_memory_utilization 0.98 \
--temperature 0.7 \
--top_p 0.9 \
--max_tokens 512 \
--tasks sorting comparison even_count find_minimum mean \
--datapoints 100 \
--folds 3 \
--range -1000 1000 \
--list_sizes 8 16 \
--seed 42 \
--store_details"

# Array of model configurations.
# Each element is a string: "model_id desired_log_filename"
# Ensure that the model_id is exactly as required by the llmthinkbench.cli tool.
declare -a model_setups
model_setups=(
    "Qwen/Qwen2.5-14B-Instruct logs-qwen14b.txt"
    # "meta-llama/Llama-3.2-3B-Instruct logs-llama3b.txt"
    # "meta-llama/Llama-3.1-8B-Instruct logs-llama8b.txt"
)

# GPU device to use
export CUDA_DEVICE_TO_USE=0

# Loop through each model setup
for setup_string in "${model_setups[@]}"; do
    # Split the string into model_id and log_file using read
    # This requires bash version 4+
    read -r model_id log_file <<< "$setup_string"

    # Alternative for older bash (less clean if filenames could have spaces, but fine here):
    # model_id=$(echo "$setup_string" | awk '{print $1}')
    # log_file=$(echo "$setup_string" | awk '{print $2}')

    echo "----------------------------------------------------------------------"
    echo "Starting experiment for model: $model_id"
    echo "Output will be logged to: $log_file"
    echo "Using CUDA_VISIBLE_DEVICES=${CUDA_DEVICE_TO_USE}"
    echo "----------------------------------------------------------------------"

    # Construct and print the command that will be run
    # The unquoted $COMMON_ARGS will undergo word splitting by the shell, which is intended here.
    full_command_display="CUDA_VISIBLE_DEVICES=${CUDA_DEVICE_TO_USE} python -m llmthinkbench.cli --model_id \"${model_id}\" ${COMMON_ARGS} > \"${log_file}\" 2>&1"
    echo "Executing command:"
    echo "$full_command_display"
    echo "" # Newline for readability before command output (if any to stdout briefly)

    # Execute the command
    # Standard output (stdout) and standard error (stderr) are redirected to the log file.
    CUDA_VISIBLE_DEVICES=${CUDA_DEVICE_TO_USE} python -m llmthinkbench.cli \
        --model_id "${model_id}" \
        ${COMMON_ARGS} \
        > "${log_file}" 2>&1

    # Check the exit status of the last command
    if [ $? -eq 0 ]; then
        echo ""
        echo "Successfully completed experiment for $model_id."
        echo "Log saved to $log_file."
    else
        echo ""
        echo "Error occurred during experiment for $model_id."
        echo "Please check $log_file for details."
    fi
    echo "----------------------------------------------------------------------"
    echo "" # Extra newline for separation
done

echo "All specified experiments have been processed."
echo "----------------------------------------------------------------------"