#!/bin/bash

# set the name of the partition to run on
#SBATCH --partition=dgx_normal_q 
# set max wallclock time
#SBATCH --time=100:00:00
# set the number of GPUs to use
#SBATCH --gres=gpu:1
# set the number of nodes and processes per node
#SBATCH --nodes=1
# set the number of tasks (processes) per node.
#SBATCH --ntasks-per-node=1
# set name of job
#SBATCH --job-name=temp_experiment3
# account name
#SBATCH --account=federatedlearning
# set CPU usage
#SBATCH --cpus-per-task=1
# mail alert at start, end and abortion of execution
#SBATCH --mail-type=ALL
# send mail to this address
#SBATCH --mail-user=sriramsrinivasan@vt.edu

# load the required modules
module load "Miniconda3/23.10.0-1"

# activate the conda environment
source activate /home/sriramsrinivasan/slm

# set the working directory to the location of the script
cd /home/sriramsrinivasan/Overthinking-Experiments/temp/Qwen2.5-14B-Instruct

# read write and execute permissions for the script
chmod 777 Qwen2.5-14B-run-temp-experiments.sh

# Loop through temperature values from 0.0 to 1.6 with 0.1 increments
for temp in $(seq 0.0 0.1 1.6); do
  # Create a directory for this temperature value
  mkdir -p "temp_${temp}"
  
  # Change into the new directory
  cd "temp_${temp}"
  
  # Run the experiment with the current temperature value
  llmthinkbench --model_id "Qwen/Qwen2.5-14B-Instruct" \
    --tensor_parallel_size 1 \
    --gpu_memory_utilization 0.95 \
    --temperature ${temp} \
    --top_p 0.9 \
    --max_tokens 1024 \
    --tasks sorting comparison even_count find_minimum mean \
    --datapoints 100 \
    --list_sizes 8 16 \
    --folds 3 \
    --range -1000 1000 \
    --store_details
  
  # Change back to the parent directory
  cd ..
done