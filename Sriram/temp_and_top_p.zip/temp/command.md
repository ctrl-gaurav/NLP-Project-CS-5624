python visualize_temp.py Qwen2.5-3B-Instruct accuracy

python visualize_temp.py <model-name-same-as-the-directory-name> <metric>