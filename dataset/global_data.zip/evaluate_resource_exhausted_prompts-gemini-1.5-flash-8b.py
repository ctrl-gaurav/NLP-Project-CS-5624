import json
import os
from google import genai
import time

# Set up the Gemini API with your API key
# Replace this with your actual API key when running the script

API_KEY1 = "AIzaSyAZtXtHoBHAmm7yNrLbLwdI1qcGggMza1E"
API_KEY2 = "AIzaSyAlR1V5Y2-ia0RtvX-DQAI5exyKndTXG00"

# Function to get response from Gemini model
def get_gemini_response(prompt, api_key):

    # Initialize the client with the provided API key
    client = genai.Client(api_key=api_key)

    try:
        # Generate response using gemini-1.5-flash-8b model
        response = client.models.generate_content(
            model="gemini-1.5-flash-8b",
            contents=prompt
        )
        
        # Return the text response
        return response.text
    except Exception as e:
        print(f"Error getting response for prompt: {e}")
        return f"Error: {str(e)}"

# Function to process a single JSON file
def process_file(file_path):
    
    # Read the JSON file
    with open(file_path, 'r') as f:
        data = json.load(f)
    
    # Ensure data is an array
    if not isinstance(data, list):
        raise ValueError("The JSON file must contain an array")
    
    print(f"Successfully loaded JSON with {len(data)} items")
    
    results = []
    times = 1
    
    # Process each item in the JSON array one by one
    for item in data:
        # Handle the item as a string prompt
        prompt = str(item)
        
        # Get response from Gemini using the appropriate API key
        if times < 1450:
            response = get_gemini_response(prompt, API_KEY1)
        else:
            response = get_gemini_response(prompt, API_KEY2)
        
        response = response.strip()

        # Add a small delay between API calls
        time.sleep(5)

        print(f"Processing item {times}/{len(data)}: {prompt[:50]}... and response: {response[:50]}...")

        # Add to results
        results.append({
            "prompt": prompt,
            "response": response
        })
        
        times += 1

        # Take a longer break every 14 requests to avoid rate limiting
        if (times % 14 == 0):
            print(f"Processed {times} prompts so far. Taking a break...")
            time.sleep(60)
    
    return results

# Main function to process all files and save results
def main():
    # Paths to the input files
    input_files = [
        '/home/sriramsrinivasan/gemini_data/resouce_exhausted_prompts/final-resource-exhausted-prompts.json',
    ]
    
    # Output file
    output_file = '/home/sriramsrinivasan/gemini_data/missed-out-prompts-gemini-1.5-flash-8b_responses.json'
    
    # Process all files and collect results
    all_results = []
    for file_path in input_files:
        print(f"Processing file: {file_path}")
        results = process_file(file_path)
        all_results.extend(results)

        # Add a delay between file processing to avoid rate limiting
        print(f"Finished processing {file_path}. Sleeping for 1 hour to avoid rate limiting.")
        # Sleep for 1 hour to avoid rate limiting
        time.sleep(3600)
    
    # Save all results to a single JSON file
    with open(output_file, 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"Processing complete. Results saved to {output_file}")

if __name__ == "__main__":
    main()