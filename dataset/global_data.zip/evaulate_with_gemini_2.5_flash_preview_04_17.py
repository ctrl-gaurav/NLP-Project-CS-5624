import json
import os
from google import genai
import time

# Set up the Gemini API with your API key
# Replace this with your actual API key when running the script
API_KEY = "AIzaSyDYXeEir1DipEw9APp6iflzqEU7Upuz3fg"
client = genai.Client(api_key=API_KEY)

# Function to get response from Gemini model
def get_gemini_response(prompt):
    try:
        # Generate response using gemini-2.0-flash model
        response = client.models.generate_content(
            model="gemini-2.5-flash-preview-04-17",
            contents=prompt
        )
        
        # Return the text response
        return response.text
    except Exception as e:
        print(f"Error getting response for prompt: {e}")
        return f"Error: {str(e)}"

# Function to process a single JSON file
def process_file(file_path):
    with open(file_path, 'r') as f:
        prompts_data = json.load(f)
    
    results = []
    times = 1
    for item in prompts_data:
        prompt = item.get('prompt', '')
        print(f"Processing prompt: {prompt[:50]}...")  # Print first 50 chars for logging
        
        # Get response from Gemini
        response = get_gemini_response(prompt)

        time.sleep(1)
        
        # Add to results
        results.append({
            "prompt": prompt,
            "response": response
        })
        
        times += 1

        if (times % 10 == 0):
            print(f"Processed {times} prompts so far.")
            # Add a small delay to avoid rate limiting
            time.sleep(60)
    
    return results

# Main function to process all files and save results
def main():
    # Paths to the input files
    input_files = [
        '/home/sriramsrinivasan/gemini_data/gemini_dataset/fold1/prompts-fold1.json',
        '/home/sriramsrinivasan/gemini_data/gemini_dataset/fold2/prompts-fold2.json',
        '/home/sriramsrinivasan/gemini_data/gemini_dataset/fold3/prompts-fold3.json'
    ]
    
    # Output file
    output_file = '/home/sriramsrinivasan/gemini_data/gemini-2.5-flash-preview-04-17_responses.json'
    
    # Process all files and collect results
    all_results = []
    for file_path in input_files:
        print(f"Processing file: {file_path}")
        results = process_file(file_path)
        all_results.extend(results)
    
    # Save all results to a single JSON file
    with open(output_file, 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"Processing complete. Results saved to {output_file}")

if __name__ == "__main__":
    main()
