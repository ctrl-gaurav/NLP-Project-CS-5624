import logging
from transformers import AutoTokenizer
from vllm import LLM
import torch  # Import torch


class ModelHandler:
    """Handler for model loading and inference"""

    def __init__(self, model_id, tensor_parallel_size=1, gpu_memory_utilization=0.9):
        """
        Initialize model handler

        Args:
            model_id: Hugging Face model ID
            tensor_parallel_size: Number of GPUs to use
            gpu_memory_utilization: GPU memory utilization threshold
        """
        self.model_id = model_id

        try:
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)  # Ensure trust_remote_code
            
            #logging.info(f"Tokenizer Info: {self.tokenizer}") #remove

            # Load model with vLLM
            self.model = LLM(
                model=model_id,
                tensor_parallel_size=tensor_parallel_size,
                max_model_len=8192,
                gpu_memory_utilization=gpu_memory_utilization,
                dtype=torch.float16, #added dtype
            )
            logging.info(f"Loaded model {model_id} with tensor_parallel_size={tensor_parallel_size} "
                         f"and gpu_memory_utilization={gpu_memory_utilization}")
        except Exception as e:
            logging.error(f"Error loading model: {e}")
            raise e

    def generate_answer(self, prompt, sampling_params):
        """
        Generate an answer using the model.

        Args:
            prompt (str): The prompt to use for generation.
            sampling_params (SamplingParams): The sampling parameters from vllm.

        Returns:
            list: A list of vllm.outputs.RequestOutput objects.
        """
        try:
            outputs = self.model.generate([prompt], sampling_params)
            return outputs
        except Exception as e:
            logging.error(f"Error during generation: {e}")
            raise e
