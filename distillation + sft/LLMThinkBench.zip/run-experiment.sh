#!/bin/bash

llmthinkbench --model_id "google/gemma-3-4b-it" --tensor_parallel_size 1 --gpu_memory_utilization 0.95 --temperature 0.7 --top_p 0.9 --max_tokens 1024 --tasks sorting comparison even_count find_minimum mean --list_sizes 8 16 --datapoints 100 --range -100 100 --store_details --seed 42 --folds 3
