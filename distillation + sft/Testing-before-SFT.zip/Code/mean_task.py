import random
import logging
from tqdm import tqdm
import os
import json
from .base_task import BaseTask
from ..utils.mean_parsing import parse_mean_answer

class MeanTask(BaseTask):
    @property
    def task_name(self):
        return "mean"
    
    def generate_data(self, list_size, fold=0):
        # data = []
        # for _ in range(self.num_samples):
        #     numbers = [random.randint(self.min_val, self.max_val) for _ in range(list_size)]
        #     # Calculate ground truth
        #     mean_value = sum(numbers) / len(numbers)
        #     data.append({"input_list": numbers, "mean": mean_value})
        # return data
        return json.load(open(f"../Data/mean-{list_size}/fold{fold}.json"))
    
    def create_prompt(self, data_point):
        return (f"Calculate the mean (average) of the following list of numbers:\n{data_point['input_list']}\n\n"
                f"The mean is the sum of all numbers divided by the count of numbers. "
                f"Calculate the exact mean value. Your final answer must be in the format "
                f"\\boxed{{mean value}} at the end.")
    
    def evaluate_response(self, response, data_point):
        # print(data_point)
        ground_truth = sum(data_point) / len(data_point)
        parsed_answer = parse_mean_answer(response)
        instruction_followed = parsed_answer is not None
        accuracy = 0
        
        # if instruction_followed:
        #     # Allow for small floating point differences
        #     accuracy = 1 if abs(parsed_answer - data_point['mean']) < 1e-6 else 0
        
        try:
            # If parsed answer is correct, set accuracy to 1 regardless of instruction following
            accuracy = 1 if abs(parsed_answer - ground_truth) < 1e-6 else 0
        except Exception as e:
            logging.debug(f"Comparison error: {e}")
            accuracy = 0
        
        return {
            "input_list": data_point,
            "ground_truth": ground_truth,
            "parsed_answer": parsed_answer,
            "accuracy": accuracy,
            "instruction_followed": instruction_followed
        }
    
    def run_evaluation(self, list_sizes):
        all_metrics = []
        
        for list_size in list_sizes:
            logging.info(f"\n{'='*40}\nEvaluating mean calculation with list size {list_size}\n{'='*40}")
            
            
            
            # Run each fold
            for fold in range(1, self.num_folds + 1):
                data = self.generate_data(list_size, fold= fold)
                metrics = self.run_fold(data, list_size, fold)
                metrics['list_size'] = list_size
                all_metrics.append(metrics)
        
        return all_metrics