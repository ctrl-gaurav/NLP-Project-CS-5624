#!/bin/sh

# Qwen/Qwen2.5-0.5B-Instruct
python absolute_difference.py Qwen/Qwen2.5-0.5B-Instruct

# Qwen/Qwen2.5-1.5B-Instruct
python absolute_difference.py Qwen/Qwen2.5-1.5B-Instruct

# Qwen/Qwen2.5-3B-Instruct
python absolute_difference.py Qwen/Qwen2.5-3B-Instruct

# Qwen/Qwen2.5-7B-Instruct
python absolute_difference.py Qwen/Qwen2.5-7B-Instruct

# Qwen/Qwen2.5-14B-Instruct 
python absolute_difference.py Qwen/Qwen2.5-14B-Instruct 

# meta-llama/Llama-3.2-1B-Instruct
python absolute_difference.py meta-llama/Llama-3.2-1B-Instruct

# meta-llama/Llama-3.2-3B-Instruct
python absolute_difference.py meta-llama/Llama-3.2-1B-Instruct

# meta-llama/Llama-3.1-8B-Instruct
python absolute_difference.py meta-llama/Llama-3.1-8B-Instruct

# mistralai/Mistral-7B-Instruct-v0.3
python absolute_difference.py mistralai/Mistral-7B-Instruct-v0.3

# mistralai/Mistral-Nemo-Instruct-2407
python absolute_difference.py mistralai/Mistral-Nemo-Instruct-2407

# HuggingFaceTB/SmolLM2-1.7B-Instruct
python absolute_difference.py HuggingFaceTB/SmolLM2-1.7B-Instruct

# microsoft/phi-4
python absolute_difference.py microsoft/phi-4

# microsoft/Phi-3-small-128k-instruct
python absolute_difference.py microsoft/Phi-3-small-128k-instruct

# microsoft/Phi-3-mini-128k-instruct
python absolute_difference.py microsoft/Phi-3-mini-128k-instruct

