import os
import json
import pandas as pd
from collections import defaultdict

def analyze_division_results(base_dir):
    """
    Analyze division experiment results across all models.
    
    Args:
        base_dir: Base directory containing model subdirectories
        
    Returns:
        tuple: (accuracy_df, instruction_followed_df) - DataFrames with results
    """
    # Dictionary to store results
    accuracy_results = defaultdict(lambda: defaultdict(list))
    instruction_followed_results = defaultdict(lambda: defaultdict(list))
    
    # Get all model directories
    model_dirs = [d for d in os.listdir(base_dir) 
                 if os.path.isdir(os.path.join(base_dir, d)) and not d.startswith('.')]
    
    # Process each model directory
    for model_id in model_dirs:
        model_path = os.path.join(base_dir, model_id)
        
        # Look for division experiment directories
        for size_dir in os.listdir(model_path):
            # Check for the specific division experiment directory pattern
            if size_dir == 'division_in_2_numbers_mixed_numbers':
                num_divisions = '2 Numbers Mixed'
            else:
                continue
                
            size_path = os.path.join(model_path, size_dir)
            
            # Process all fold files
            for fold_file in os.listdir(size_path):
                if not fold_file.startswith('results_fold_') or not fold_file.endswith('.json'):
                    continue
                    
                fold_path = os.path.join(size_path, fold_file)
                
                # Load JSON data
                with open(fold_path, 'r') as f:
                    results = json.load(f)
                
                # Extract accuracy and instruction followed metrics
                for result in results:
                    accuracy_results[model_id][num_divisions].append(result['accuracy'])
                    instruction_followed_results[model_id][num_divisions].append(
                        1 if result['Instruction_followed'] else 0
                    )
    
    # Calculate average accuracy and instruction followed percentages
    accuracy_data = {}
    instruction_followed_data = {}
    
    for model_id in accuracy_results:
        accuracy_data[model_id] = {}
        instruction_followed_data[model_id] = {}
        
        for num_div in ['2 Numbers Mixed']:
            if num_div in accuracy_results[model_id]:
                # Calculate accuracy percentage
                accuracy = sum(accuracy_results[model_id][num_div]) / len(accuracy_results[model_id][num_div]) * 100
                accuracy_data[model_id][num_div] = round(accuracy, 2)
            else:
                accuracy_data[model_id][num_div] = 'N/A'
                
            if num_div in instruction_followed_results[model_id]:
                # Calculate instruction followed percentage
                inst_followed = sum(instruction_followed_results[model_id][num_div]) / len(instruction_followed_results[model_id][num_div]) * 100
                instruction_followed_data[model_id][num_div] = round(inst_followed, 2)
            else:
                instruction_followed_data[model_id][num_div] = 'N/A'
    
    # Convert to DataFrames
    accuracy_df = pd.DataFrame.from_dict(accuracy_data, orient='index')
    instruction_followed_df = pd.DataFrame.from_dict(instruction_followed_data, orient='index')
    
    # Ensure columns are in the right order
    columns = ['2 Numbers Mixed']
    accuracy_df = accuracy_df.reindex(columns=columns)
    instruction_followed_df = instruction_followed_df.reindex(columns=columns)
    
    return accuracy_df, instruction_followed_df

def main():
    base_dir = '/home/sriramsrinivasan/division-experiments'
    
    # Analyze results
    accuracy_df, instruction_followed_df = analyze_division_results(base_dir)
    
    # Print results
    print("\n===== MODEL ACCURACY PERCENTAGES =====")
    print("(Percentage of correct answers)\n")
    print(accuracy_df.to_string(float_format=lambda x: f"{x:.2f}%"))
    
    print("\n\n===== MODEL INSTRUCTION FOLLOWED PERCENTAGES =====")
    print("(Percentage of responses using the requested \\boxed{} format)\n")
    print(instruction_followed_df.to_string(float_format=lambda x: f"{x:.2f}%"))
    
    # Save results to CSV
    accuracy_df.to_csv(os.path.join(base_dir, 'accuracy_results.csv'))
    instruction_followed_df.to_csv(os.path.join(base_dir, 'instruction_followed_results.csv'))
    
    print("\nResults saved to CSV files in the division-experiments directory.")

if __name__ == "__main__":
    main()
