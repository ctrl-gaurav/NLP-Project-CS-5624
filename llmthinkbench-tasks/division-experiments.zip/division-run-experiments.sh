#!/bin/sh

# Qwen/Qwen2.5-0.5B-Instruct
python division.py Qwen/Qwen2.5-0.5B-Instruct

# Qwen/Qwen2.5-1.5B-Instruct
python division.py Qwen/Qwen2.5-1.5B-Instruct

# Qwen/Qwen2.5-3B-Instruct
python division.py Qwen/Qwen2.5-3B-Instruct

# Qwen/Qwen2.5-7B-Instruct
python division.py Qwen/Qwen2.5-7B-Instruct

# Qwen/Qwen2.5-14B-Instruct 
python division.py Qwen/Qwen2.5-14B-Instruct 

# meta-llama/Llama-3.2-1B-Instruct
python division.py meta-llama/Llama-3.2-1B-Instruct

# meta-llama/Llama-3.2-3B-Instruct
python division.py meta-llama/Llama-3.2-1B-Instruct

# meta-llama/Llama-3.1-8B-Instruct
python division.py meta-llama/Llama-3.1-8B-Instruct

# mistralai/Mistral-7B-Instruct-v0.3
python division.py mistralai/Mistral-7B-Instruct-v0.3

# mistralai/Mistral-Nemo-Instruct-2407
python division.py mistralai/Mistral-Nemo-Instruct-2407

# HuggingFaceTB/SmolLM2-1.7B-Instruct
python division.py HuggingFaceTB/SmolLM2-1.7B-Instruct

# microsoft/phi-4
python division.py microsoft/phi-4

# microsoft/Phi-4-mini-instruct
python division.py microsoft/Phi-4-mini-instruct

# microsoft/Phi-3-small-128k-instruct
python division.py microsoft/Phi-3-small-128k-instruct

# microsoft/Phi-3-mini-128k-instruct
python division.py microsoft/Phi-3-mini-128k-instruct

