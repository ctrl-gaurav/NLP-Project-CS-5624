import json
import sys
import os
import csv
from collections import defaultdict

# Add parent directory to path to import parse_response.py
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from parse_response_min import extract_answer_from_response

def main():
    # Path to the JSON file
    json_file_path = "/home/sriramsrinivasan/find-minimum-experiments/min-tasks.json"
    
    # Load the JSON data
    try:
        with open(json_file_path, 'r') as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error loading JSON file: {e}")
        return
    
    print(f"Loaded {len(data)} items from the JSON file")
    
    # Track statistics
    total_items = len(data)
    correct_answers = 0
    instruction_followed_count = 0
    
    # Track statistics by model and task
    model_stats = defaultdict(lambda: {
        'total': 0,
        'correct': 0,
        'instruction_followed': 0,
        'accuracy': 0,
        'instruction_followed_rate': 0
    })
    
    task_stats = defaultdict(lambda: {
        'total': 0,
        'correct': 0,
        'instruction_followed': 0,
        'accuracy': 0,
        'instruction_followed_rate': 0
    })
    
    # Prepare data for detailed analysis
    results_data = []
    
    # Process each item
    for i, item in enumerate(data):
        model_response = item.get("model_response")
        min_number = item.get("min_number")
        model_id = item.get("model-id", "unknown")
        task_name = item.get("task", "unknown")
        fold = item.get("fold", "unknown")
        original_parsed_min = item.get("parsed_min")
        
        if model_response is None or min_number is None:
            print(f"Item {i} is missing required fields")
            continue
        
        # Parse the response using the extract_answer_from_response function
        instruction_followed, parsed_answer = extract_answer_from_response(model_response)
        
        # Check if the answer is correct
        is_correct = parsed_answer == min_number
        
        # Update statistics
        if is_correct:
            correct_answers += 1
        if instruction_followed:
            instruction_followed_count += 1
        
        # Update model statistics
        model_stats[model_id]['total'] += 1
        if is_correct:
            model_stats[model_id]['correct'] += 1
        if instruction_followed:
            model_stats[model_id]['instruction_followed'] += 1
        
        # Update task statistics
        task_stats[task_name]['total'] += 1
        if is_correct:
            task_stats[task_name]['correct'] += 1
        if instruction_followed:
            task_stats[task_name]['instruction_followed'] += 1
        
        # Add to results data
        results_data.append({
            'model_id': model_id,
            'task': task_name,
            'fold': fold,
            'min_number': min_number,
            'parsed_min': parsed_answer,
            'original_parsed_min': original_parsed_min,
            'instruction_followed': instruction_followed,
            'is_correct': is_correct,
            'parser_match': parsed_answer == original_parsed_min
        })
        
        # Print details for this item (limit to first 10 for brevity)
        if i < 10:
            print(f"Item {i+1}/{total_items} (Model: {model_id}, Task: {task_name}, Fold: {fold}):")
            print(f"  Min number: {min_number}")
            print(f"  Parsed answer: {parsed_answer}")
            print(f"  Original parsed answer: {original_parsed_min}")
            print(f"  Parser match: {parsed_answer == original_parsed_min}")
            print(f"  Instruction followed: {instruction_followed}")
            print(f"  Correct: {is_correct}")
            print()
    
    # Calculate overall accuracy
    accuracy = correct_answers / total_items if total_items > 0 else 0
    instruction_followed_rate = instruction_followed_count / total_items if total_items > 0 else 0
    
    # Calculate model-specific accuracy
    for model_id, stats in model_stats.items():
        stats['accuracy'] = stats['correct'] / stats['total'] if stats['total'] > 0 else 0
        stats['instruction_followed_rate'] = stats['instruction_followed'] / stats['total'] if stats['total'] > 0 else 0
    
    # Calculate task-specific accuracy
    for task_name, stats in task_stats.items():
        stats['accuracy'] = stats['correct'] / stats['total'] if stats['total'] > 0 else 0
        stats['instruction_followed_rate'] = stats['instruction_followed'] / stats['total'] if stats['total'] > 0 else 0
    
    # Print overall results
    print(f"Overall Results:")
    print(f"  Total items: {total_items}")
    print(f"  Correct answers: {correct_answers}")
    print(f"  Accuracy: {accuracy:.2%}")
    print(f"  Instructions followed: {instruction_followed_count}")
    print(f"  Instruction followed rate: {instruction_followed_rate:.2%}")
    
    # Print model-specific results
    print("\nResults by Model:")
    for model_id, stats in sorted(model_stats.items(), key=lambda x: x[1]['accuracy'], reverse=True):
        print(f"  {model_id}:")
        print(f"    Total items: {stats['total']}")
        print(f"    Correct answers: {stats['correct']}")
        print(f"    Accuracy: {stats['accuracy']:.2%}")
        print(f"    Instructions followed: {stats['instruction_followed']}")
        print(f"    Instruction followed rate: {stats['instruction_followed_rate']:.2%}")
    
    # Print task-specific results
    print("\nResults by Task:")
    for task_name, stats in sorted(task_stats.items(), key=lambda x: x[1]['accuracy'], reverse=True):
        print(f"  {task_name}:")
        print(f"    Total items: {stats['total']}")
        print(f"    Correct answers: {stats['correct']}")
        print(f"    Accuracy: {stats['accuracy']:.2%}")
        print(f"    Instructions followed: {stats['instruction_followed']}")
        print(f"    Instruction followed rate: {stats['instruction_followed_rate']:.2%}")
    
    # Calculate parser agreement rate
    parser_matches = sum(1 for item in results_data if item['parser_match'])
    parser_agreement = parser_matches / total_items if total_items > 0 else 0
    print(f"\nParser Agreement Rate: {parser_agreement:.2%}")
    
    # Analyze cases where the parsers disagree
    disagreements = [item for item in results_data if not item['parser_match']]
    print(f"\nNumber of parser disagreements: {len(disagreements)}")
    
    # Save detailed results to CSV for further analysis
    output_csv = "/home/sriramsrinivasan/find-minimum-experiments/min_tasks_analysis.csv"
    with open(output_csv, 'w', newline='') as csvfile:
        fieldnames = ['model_id', 'task', 'fold', 'min_number', 'parsed_min', 'original_parsed_min', 
                     'instruction_followed', 'is_correct', 'parser_match']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for item in results_data:
            writer.writerow(item)
    
    print(f"\nDetailed results saved to {output_csv}")

if __name__ == "__main__":
    main()
