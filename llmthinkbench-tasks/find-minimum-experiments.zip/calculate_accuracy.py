import csv
from collections import defaultdict

def main():
    # Path to the CSV file
    csv_file_path = "/home/sriramsrinivasan/find-minimum-experiments/min_tasks_analysis.csv"
    
    # Dictionary to store accuracy and instruction followed by model and task
    stats_by_model_task = defaultdict(lambda: defaultdict(lambda: {
        'correct': 0, 
        'total': 0, 
        'instruction_followed': 0
    }))
    
    # Read the CSV file
    with open(csv_file_path, 'r') as f:
        # The CSV file seems to have issues with column separation
        # Let's try to fix it by splitting the header line
        header_line = f.readline().strip()
        headers = header_line.split(',')
        
        # If there are no commas, try splitting by other characters
        if len(headers) == 1:
            for separator in ['\t', ';']:
                headers = header_line.split(separator)
                if len(headers) > 1:
                    break
        
        # If we still have only one column, assume it's a single string with no separators
        if len(headers) == 1:
            # Try to identify column positions based on known column names
            header_str = headers[0]
            col_positions = {}
            for col_name in ['model_id', 'task', 'fold', 'min_number', 'parsed_min', 'original_parsed_min', 'instruction_followed', 'is_correct', 'parser_match']:
                pos = header_str.find(col_name)
                if pos >= 0:
                    col_positions[col_name] = pos
            
            # Sort column positions
            sorted_cols = sorted(col_positions.items(), key=lambda x: x[1])
            col_names = [col[0] for col in sorted_cols]
            
            # Process each line
            for line in f:
                line = line.strip()
                
                # Extract values based on column positions
                values = {}
                for i in range(len(sorted_cols)):
                    start_pos = sorted_cols[i][1]
                    end_pos = sorted_cols[i+1][1] if i < len(sorted_cols) - 1 else len(line)
                    values[sorted_cols[i][0]] = line[start_pos:end_pos].strip()
                
                model_id = values.get('model_id', 'unknown')
                task = values.get('task', 'unknown')
                is_correct = values.get('is_correct', 'False') == 'True'
                instruction_followed = values.get('instruction_followed', 'False') == 'True'
                
                # Update statistics
                stats_by_model_task[model_id][task]['total'] += 1
                if is_correct:
                    stats_by_model_task[model_id][task]['correct'] += 1
                if instruction_followed:
                    stats_by_model_task[model_id][task]['instruction_followed'] += 1
        else:
            # Process the file as a normal CSV
            reader = csv.DictReader(f, fieldnames=headers)
            
            for row in reader:
                model_id = row.get('model_id', 'unknown')
                task = row.get('task', 'unknown')
                is_correct = row.get('is_correct', 'False') == 'True'
                instruction_followed = row.get('instruction_followed', 'False') == 'True'
                
                # Update statistics
                stats_by_model_task[model_id][task]['total'] += 1
                if is_correct:
                    stats_by_model_task[model_id][task]['correct'] += 1
                if instruction_followed:
                    stats_by_model_task[model_id][task]['instruction_followed'] += 1
    
    # Calculate overall statistics by model
    model_stats = {}
    for model_id, tasks in stats_by_model_task.items():
        total_correct = sum(task_stats['correct'] for task_stats in tasks.values())
        total_instruction_followed = sum(task_stats['instruction_followed'] for task_stats in tasks.values())
        total_items = sum(task_stats['total'] for task_stats in tasks.values())
        
        model_stats[model_id] = {
            'accuracy': (total_correct / total_items) * 100 if total_items > 0 else 0,
            'instruction_followed': (total_instruction_followed / total_items) * 100 if total_items > 0 else 0
        }
    
    # Calculate overall statistics by task
    task_stats = {}
    all_tasks = set()
    for tasks in stats_by_model_task.values():
        all_tasks.update(tasks.keys())
    
    for task in all_tasks:
        total_correct = sum(tasks[task]['correct'] for tasks in stats_by_model_task.values() if task in tasks)
        total_instruction_followed = sum(tasks[task]['instruction_followed'] for tasks in stats_by_model_task.values() if task in tasks)
        total_items = sum(tasks[task]['total'] for tasks in stats_by_model_task.values() if task in tasks)
        
        task_stats[task] = {
            'accuracy': (total_correct / total_items) * 100 if total_items > 0 else 0,
            'instruction_followed': (total_instruction_followed / total_items) * 100 if total_items > 0 else 0
        }
    
    # Print accuracy and instruction followed by model (sorted by accuracy)
    print("Model Performance (sorted by accuracy):")
    print("Model, Accuracy (%), Instruction Followed (%)")
    for model_id, stats in sorted(model_stats.items(), key=lambda x: x[1]['accuracy'], reverse=True):
        print(f"{model_id}, {stats['accuracy']:.2f}%, {stats['instruction_followed']:.2f}%")
    
    print("\nTask Performance (sorted by accuracy):")
    print("Task, Accuracy (%), Instruction Followed (%)")
    for task, stats in sorted(task_stats.items(), key=lambda x: x[1]['accuracy'], reverse=True):
        print(f"{task}, {stats['accuracy']:.2f}%, {stats['instruction_followed']:.2f}%")
    
    # Save the detailed statistics to a CSV file
    output_csv = "/home/sriramsrinivasan/find-minimum-experiments/model_task_performance.csv"
    with open(output_csv, 'w', newline='') as csvfile:
        # Write header
        csvfile.write("Model,Accuracy (%),Instruction Followed (%),Task Breakdown\n")
        
        # Write data
        for model_id, stats in sorted(model_stats.items(), key=lambda x: x[1]['accuracy'], reverse=True):
            csvfile.write(f"{model_id},{stats['accuracy']:.2f}%,{stats['instruction_followed']:.2f}%,")
            
            # Add task breakdown
            task_breakdown = []
            for task in sorted(all_tasks):
                if task in stats_by_model_task[model_id]:
                    task_stats = stats_by_model_task[model_id][task]
                    accuracy = (task_stats['correct'] / task_stats['total']) * 100 if task_stats['total'] > 0 else 0
                    instruction_followed = (task_stats['instruction_followed'] / task_stats['total']) * 100 if task_stats['total'] > 0 else 0
                    task_breakdown.append(f"{task}: {accuracy:.2f}% acc, {instruction_followed:.2f}% inst")
            
            csvfile.write("; ".join(task_breakdown) + "\n")
    
    print(f"\nDetailed performance statistics saved to {output_csv}")

if __name__ == "__main__":
    main()
