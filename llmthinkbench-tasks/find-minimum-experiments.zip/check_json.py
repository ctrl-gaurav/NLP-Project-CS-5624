import json

try:
    with open('minimum-experiments-instruction-followed-false.json', 'r') as f:
        data = json.load(f)
    print('JSON is valid')
    print(f'Number of items: {len(data)}')
    if len(data) > 0:
        print('First item sample:')
        first_item = data[0]
        # Print specific fields we're interested in
        print(f"Instruction_followed: {first_item.get('Instruction_followed')}")
        print(f"model-id: {first_item.get('model-id')}")
        # Print a few more fields if they exist
        for field in ['min_number', 'parsed_min', 'accuracy']:
            if field in first_item:
                print(f"{field}: {first_item.get(field)}")
except json.JSONDecodeError as e:
    print(f'JSON is invalid: {e}')
