import json

try:
    with open('minimum-experiments-instruction-followed-false.json', 'r') as f:
        data = json.load(f)
    
    # Count items by model-id
    model_counts = {}
    for item in data:
        model_id = item.get('model-id', 'unknown')
        model_counts[model_id] = model_counts.get(model_id, 0) + 1
    
    # Print counts
    print(f"Total items: {len(data)}")
    print("\nItems by model:")
    for model, count in sorted(model_counts.items()):
        print(f"{model}: {count}")
    
except json.JSONDecodeError as e:
    print(f'JSON is invalid: {e}')
