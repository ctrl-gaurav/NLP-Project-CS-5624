import os
import json
from pathlib import Path

def main():
    # Base directory containing all model directories
    base_dir = Path("/home/sriramsrinivasan/find-minimum-experiments")
    
    # Output file path
    output_file = base_dir / "minimum-experiments-instruction-followed-false.json"
    
    # List to store all matching JSON objects
    all_matches = []
    
    # Get all directories in the base directory
    model_dirs = [d for d in base_dir.iterdir() if d.is_dir() and not d.name.startswith('.')]
    
    # Process each model directory
    for model_dir in model_dirs:
        model_id = model_dir.name
        print(f"Processing model directory: {model_id}")
        
        # Get all experiment directories in the model directory
        experiment_dirs = [d for d in model_dir.iterdir() if d.is_dir()]
        
        # Process each experiment directory
        for experiment_dir in experiment_dirs:
            print(f"  Processing experiment directory: {experiment_dir.name}")
            
            # Get all JSON files in the experiment directory
            json_files = [f for f in experiment_dir.iterdir() if f.suffix.lower() == '.json']
            
            # Process each JSON file
            for json_file in json_files:
                print(f"    Processing JSON file: {json_file.name}")
                
                try:
                    # Load the JSON data
                    with open(json_file, 'r') as f:
                        data = json.load(f)
                    
                    # Check if data is a list
                    if isinstance(data, list):
                        # Find objects with "Instruction_followed": false
                        for item in data:
                            if isinstance(item, dict) and item.get("Instruction_followed") is False:
                                # Add model-id field
                                item_copy = item.copy()
                                item_copy["model-id"] = model_id
                                all_matches.append(item_copy)
                except Exception as e:
                    print(f"    Error processing {json_file}: {e}")
    
    # Write all matches to the output file
    print(f"Writing {len(all_matches)} matches to {output_file}")
    with open(output_file, 'w') as f:
        json.dump(all_matches, f, indent=4)
    
    print("Done!")

if __name__ == "__main__":
    main()
