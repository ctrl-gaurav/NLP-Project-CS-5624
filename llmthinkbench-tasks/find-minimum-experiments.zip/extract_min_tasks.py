import json
import os
import glob

def extract_fields_from_json(json_file_path):
    """
    Extract specific fields from a JSON file.
    
    Args:
        json_file_path (str): Path to the JSON file
        
    Returns:
        list: List of dictionaries containing the extracted fields
    """
    try:
        with open(json_file_path, 'r') as f:
            data = json.load(f)
        
        # Extract model ID from the directory path
        # Format: /path/to/model-name/task-name/results_fold_X.json
        parts = json_file_path.split('/')
        model_id = parts[-3] if len(parts) >= 3 else "unknown"
        
        # Extract task name from the directory path
        task_name = parts[-2] if len(parts) >= 2 else "unknown"
        
        # Extract fold number from the filename
        fold = "unknown"
        if "fold" in parts[-1]:
            fold = parts[-1].split("_")[-1].split(".")[0]
        
        extracted_data = []
        
        for item in data:
            # Extract required fields
            extracted_item = {
                "min_number": item.get("min_number"),
                "model_response": item.get("model_response"),
                "parsed_min": item.get("parsed_min"),
                "model-id": model_id,
                "task": task_name,
                "fold": fold
            }
            
            # Add any other fields that might be present
            for key, value in item.items():
                if key not in extracted_item and key != "model_response":
                    extracted_item[key] = value
            
            extracted_data.append(extracted_item)
        
        return extracted_data
    
    except Exception as e:
        print(f"Error processing {json_file_path}: {e}")
        return []

def main():
    # Base directory
    base_dir = "/home/sriramsrinivasan/find-minimum-experiments"
    
    # Output file
    output_file = os.path.join(base_dir, "min-tasks.json")
    
    # Find all JSON files in subdirectories
    json_files = glob.glob(os.path.join(base_dir, "**", "*.json"), recursive=True)
    
    # Filter out the output file itself and any other non-results files
    json_files = [f for f in json_files if "results_fold" in f]
    
    print(f"Found {len(json_files)} JSON files to process")
    
    # Extract data from all JSON files
    all_data = []
    
    for json_file in json_files:
        print(f"Processing {json_file}")
        extracted_data = extract_fields_from_json(json_file)
        all_data.extend(extracted_data)
    
    print(f"Extracted {len(all_data)} items in total")
    
    # Save the extracted data to the output file
    with open(output_file, 'w') as f:
        json.dump(all_data, f, indent=2)
    
    print(f"Saved extracted data to {output_file}")

if __name__ == "__main__":
    main()
