import os
import json
import sys
from parse_response_product import extract_answer_from_response

# Base directory
base_dir = "/home/sriramsrinivasan/multiplication-experiments"
output_file = os.path.join(base_dir, "mul-inst-followed-false.json")

# List to store results
results = []

# Traverse model directories
for model_dir in os.listdir(base_dir):
    model_path = os.path.join(base_dir, model_dir)
    
    # Skip non-directories and special directories
    if not os.path.isdir(model_path) or model_dir.startswith('__') or model_dir.startswith('.'):
        continue
    
    # Skip non-model directories
    if model_dir in ["__pycache__"] or model_dir.endswith(".json") or model_dir.endswith(".py") or model_dir.endswith(".sh"):
        continue
    
    # Traverse experiment directories
    for exp_dir in os.listdir(model_path):
        exp_path = os.path.join(model_path, exp_dir)
        
        if not os.path.isdir(exp_path):
            continue
        
        # Traverse JSON files
        for json_file in os.listdir(exp_path):
            if not json_file.endswith('.json'):
                continue
            
            json_path = os.path.join(exp_path, json_file)
            
            # Read JSON file
            with open(json_path, 'r') as f:
                data = json.load(f)
            
            # Extract required fields from objects where "Instruction_followed" is false
            for item in data:
                if item.get("Instruction_followed") == False:
                    # Re-parse the response with the updated function that avoids input numbers
                    prompt = item.get("prompt")
                    model_response = item.get("model_response")
                    instruction_followed, parsed_product = extract_answer_from_response(model_response, prompt)
                    
                    results.append({
                        "product": item.get("product"),
                        "prompt": prompt,
                        "model_response": model_response,
                        "parsed_product": parsed_product,
                        "accuracy": 1 if parsed_product == item.get("product") else 0,
                        "model_id": model_dir
                    })

# Write results to output file
with open(output_file, 'w') as f:
    json.dump(results, f, indent=4)

print(f"Extracted {len(results)} items where Instruction_followed is False")
print(f"Of these, {sum(item['accuracy'] for item in results)} were correctly parsed with the improved parser")
