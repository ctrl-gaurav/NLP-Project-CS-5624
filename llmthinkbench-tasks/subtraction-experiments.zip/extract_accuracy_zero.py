#!/usr/bin/env python3
import os
import json

def extract_accuracy_zero_objects(base_dir, output_file):
    """
    Extract all JSON objects with accuracy=0 from all subdirectories.
    
    Args:
        base_dir: Base directory containing model subdirectories
        output_file: Path to output JSON file
    """
    # List to store all matching objects
    accuracy_zero_objects = []
    
    # Get all model directories
    model_dirs = [d for d in os.listdir(base_dir) 
                 if os.path.isdir(os.path.join(base_dir, d)) and not d.startswith('.')]
    
    # Process each model directory
    for model_id in model_dirs:
        model_path = os.path.join(base_dir, model_id)
        
        # Skip directories that don't look like model directories
        if model_id.startswith('__') or model_id == 'node_modules':
            continue
            
        try:
            # Look for subtraction experiment directories
            for size_dir in os.listdir(model_path):
                # Check for the specific subtraction experiment directory pattern
                if size_dir == 'subtraction_in_2_numbers_mixed_numbers':
                    size_path = os.path.join(model_path, size_dir)
                    
                    # Process all fold files
                    for fold_file in os.listdir(size_path):
                        if not fold_file.startswith('results_fold_') or not fold_file.endswith('.json'):
                            continue
                            
                        fold_path = os.path.join(size_path, fold_file)
                        
                        # Load JSON data
                        with open(fold_path, 'r') as f:
                            results = json.load(f)
                        
                        # Extract objects with accuracy=0
                        for result in results:
                            if result['accuracy'] == 0:
                                # Extract required fields
                                extracted_obj = {
                                    'difference': result['difference'],
                                    'prompt': result['prompt'],
                                    'model_response': result['model_response'],
                                    'parsed_difference': result['parsed_difference'],
                                    'accuracy': result['accuracy'],
                                    'Instruction_followed': result['Instruction_followed'],
                                    'model_id': model_id
                                }
                                accuracy_zero_objects.append(extracted_obj)
        except (FileNotFoundError, NotADirectoryError, PermissionError) as e:
            print(f"Error processing directory {model_id}: {e}")
    
    # Write to output file
    with open(output_file, 'w') as f:
        json.dump(accuracy_zero_objects, f, indent=4)
    
    print(f"Extracted {len(accuracy_zero_objects)} objects with accuracy=0 to {output_file}")
    return len(accuracy_zero_objects)

def main():
    base_dir = '/home/sriramsrinivasan/subtraction-experiments'
    output_file = os.path.join(base_dir, 'sub-accuracy-0.json')
    
    count = extract_accuracy_zero_objects(base_dir, output_file)
    print(f"Total objects with accuracy=0: {count}")

if __name__ == "__main__":
    main()
