import re

def extract_answer_from_response(clean_response, prompt=None):
    """
    Extract an answer from the LLM response with robust pattern matching.
    
    This function attempts to extract the answer from various formats that LLMs might use,
    prioritizing the requested format (boxed) and falling back to other common patterns.
    It also avoids extracting numbers from the input list if prompt is provided.
    
    Args:
        clean_response (str): The cleaned response from the LLM
        prompt (str, optional): The prompt that was given to the LLM
        
    Returns:
        tuple: (bool, value) where bool indicates if instruction was followed
               and value is the extracted answer or None
    """
    # Extract input numbers from prompt if available
    input_numbers = []
    if prompt:
        input_numbers = extract_input_numbers_from_prompt(prompt)
    
    # 1. Try to extract from boxed formats (highest priority)
    boxed_answer, instruction_followed = extract_from_boxed_formats(clean_response)
    if boxed_answer is not None:
        answer = clean_and_convert_to_number(boxed_answer)
        if is_valid_number(answer) and not is_input_number(answer, input_numbers):
            # Check if the original boxed answer had a negative sign
            if isinstance(boxed_answer, str) and boxed_answer.strip().startswith('-') and isinstance(answer, (int, float)) and answer > 0:
                answer = -answer
            # Check for negative signs in the boxed format in the response
            elif isinstance(answer, (int, float)) and answer > 0:
                if "\\boxed{-" in clean_response or "\\boxed{\\text{-}" in clean_response or "\\boxed{\\textbf{-}" in clean_response:
                    answer = -answer
                # Look for negative signs in calculation steps
                elif re.search(r'[-]\d+\s*[+]\s*\d+\s*=\s*[-]\d+', clean_response) or re.search(r'[-]\d+\s*[-]\s*\d+\s*=\s*[-]\d+', clean_response):
                    answer = -answer
            return instruction_followed, answer
    
    # No valid answer found
    return False, None


def is_valid_number(value):
    """
    Check if a value is a valid number.
    
    Args:
        value: The value to check
        
    Returns:
        bool: True if the value is a valid number, False otherwise
    """
    if value is None:
        return False
    
    if isinstance(value, (int, float)):
        return True
    
    if isinstance(value, str):
        try:
            # Try to convert to a number
            float(value)
            return True
        except ValueError:
            pass
    
    return False


def extract_input_numbers_from_prompt(prompt):
    """
    Extract the input numbers from the prompt.
    
    Args:
        prompt (str): The prompt that was given to the LLM
        
    Returns:
        list: The list of input numbers
    """
    # Look for a list pattern in the prompt
    list_match = re.search(r'\[([-+]?\d+(?:,\s*[-+]?\d+)*)\]', prompt)
    if list_match:
        # Extract the numbers from the list
        numbers_str = list_match.group(1)
        # Split by comma and convert to numbers
        try:
            numbers = [int(num.strip()) for num in numbers_str.split(',')]
            return numbers
        except ValueError:
            pass
    
    return []


def is_input_number(number, input_numbers):
    """
    Check if a number is one of the input numbers or a simple combination of them.
    
    Args:
        number: The number to check
        input_numbers (list): The list of input numbers from the prompt
        
    Returns:
        bool: True if the number is one of the input numbers, False otherwise
    """
    if not input_numbers:
        return False
    
    # Convert to int or float for comparison
    if isinstance(number, str):
        try:
            number = int(float(number))
        except ValueError:
            try:
                number = float(number)
            except ValueError:
                return False
    
    # Check if the number is one of the input numbers
    if number in input_numbers:
        return True
    
    # Check if the number is a simple sum of input numbers
    if len(input_numbers) > 1 and number == sum(input_numbers):
        return True
    
    # Check if the number is one of the input numbers with a sign change
    if -number in input_numbers:
        return True
    
    return False


def clean_and_convert_to_number(text):
    """
    Clean the text and convert it to a number if possible.
    
    Args:
        text (str or int or float): The text or number to clean and convert
        
    Returns:
        int, float, or str: The converted number or the original text if conversion fails
    """
    if not text:
        return None
    
    # If text is already a number, return it
    if isinstance(text, (int, float)):
        return text
    
    # Convert to string if it's not already
    if not isinstance(text, str):
        try:
            text = str(text)
        except:
            return None
    
    # Remove LaTeX formatting
    text = re.sub(r'\\[a-zA-Z]+', '', text)
    
    # Remove markdown formatting (bold, italic, code)
    text = re.sub(r'[*_~`]', '', text)
    
    # Handle cases where there's a space between the minus sign and the number
    text = re.sub(r'-\s+(\d+)', r'-\1', text)
    
    # Remove commas from numbers (e.g., 1,234,567)
    text = re.sub(r'(\d),(\d)', r'\1\2', text)
    
    # Try to convert to a number
    try:
        # Extract the first number from the text, including scientific notation
        number_match = re.search(r'([+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)', text)
        if number_match:
            number_str = number_match.group(1)
            # Convert to float first to preserve the sign, then to int if appropriate
            result = float(number_str)
            if '.' not in number_str and 'e' not in number_str.lower():
                return int(result)
            else:
                return result
    except ValueError:
        pass
    
    # Return the cleaned text if conversion fails
    return text


def extract_from_boxed_formats(text):
    """
    Extract answers from various boxed formats.
    
    This function looks for different LaTeX-style boxed formats that LLMs might use,
    including standard \boxed{}, parenthesized \(\boxed{}\), and bracketed \[\boxed{}\].
    
    Args:
        text (str): The text to search for boxed formats
        
    Returns:
        tuple: (extracted_answer, instruction_followed)
               extracted_answer is the content inside the box or None
               instruction_followed is True if the exact requested format was used
    """
    # Look for standard LaTeX boxed format: \boxed{answer}
    standard_boxed = re.findall(r'\\boxed\{([^{}]*)\}', text)
    
    # Look for LaTeX boxed format with parentheses: \(\boxed{answer}\)
    paren_boxed = re.findall(r'\\[\(\[]\\boxed\{([^{}]*)\}\\[\)\]]', text)
    
    # Look for formats with negative signs in different positions
    neg_boxed = re.findall(r'\\boxed\{-\s*([^{}]*)\}', text)
    
    # Combine all matches
    all_matches = standard_boxed + paren_boxed
    
    # Process negative boxed formats
    for match in neg_boxed:
        try:
            value = "-" + match
            all_matches.append(value)
        except (ValueError, TypeError):
            pass
    
    if all_matches:
        # Return the last match as it's likely the final answer
        return all_matches[-1].strip(), True
    
    return None, False
