from vllm import LLM, SamplingParams
from transformers import AutoTokenizer
from huggingface_hub import notebook_login
 
import os
import sys
import time
import json
import random
import re
from tqdm import tqdm

# Add parent directory to path to import parse_response.py
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from parse_response_subtraction import extract_answer_from_response
 
def generate_numbers_list(size, num_samples=50, include_negatives=False):
    """Generate random lists of numbers."""
    if include_negatives:
        return [random.sample(range(-100, 101), size) for _ in range(num_samples)]
    else:
        return [random.sample(range(1, 101), size) for _ in range(num_samples)]
    
def calculate_difference(numbers):
    """Return the difference of the 2 numbers."""
    if len(numbers) != 2:
        raise ValueError("List must contain exactly two numbers.")
    result = numbers[1] - numbers[0]
    return result
    
def evaluate_subtraction_task(numbers_list, output_dir, llm, tokenizer, sampling_params, num_folds=3):
    """Evaluate the model's ability to calculate difference in 2 numbers."""
    for fold in range(1, num_folds + 1):
        print(f"Starting Fold {fold} Evaluation for Subtraction Task...")
        results = []
        generation_times = []
 
        for idx, numbers in enumerate(tqdm(numbers_list, desc=f"Evaluating Fold {fold}")):
            
            # Ground truth absolute difference of the 2 given numbers
            ground_truth = calculate_difference(numbers)
 
            # Construct prompt
            prompt = f"Can you subtract {numbers[0]} from {numbers[1]} and provide your final answer in \\boxed{{answer}} format at the end of your response."
            prompt = prompt.strip()
            messages = [
                {
                    "role": "user",
                    "content": prompt
                }
            ]
 
            prompts = tokenizer.apply_chat_template(messages, add_generation_prompt=True, tokenize=False)
 
            # Measure generation time
            start_gen = time.time()
            outputs = llm.generate(prompts, sampling_params, use_tqdm=False)
            elapsed_gen = time.time() - start_gen
            generation_times.append(elapsed_gen)
 
            response = outputs[0].outputs[0].text
 
            # Clean model response
            if "assistant\n" in response:
                clean_response = response.split("assistant\n", 1)[-1].strip()
            else:
                clean_response = response.strip()
            
            # Count words in response
            words = len(clean_response.split())
            
            instruction_followed, answer = extract_answer_from_response(clean_response)
            
            # check if answer is number and convert it to int, else keep the string as is
            # if instruction_followed and answer:
            #     # answer is number
            #     try:
            #         answer = int(float(answer))
            #     except ValueError:
            #         pass
            
            accuracy = 0
            if (ground_truth == answer):
                accuracy = 1

            results.append({
                "generated_numbers": numbers,
                "difference": ground_truth,
                "prompt": prompt,
                "model_response": clean_response,
                "parsed_difference": answer,
                "accuracy": accuracy,
                "string_length": len(clean_response),
                "words": words,
                "Instruction_followed": instruction_followed})
 
        # Save results to JSON file
        output_file = os.path.join(output_dir, f"results_fold_{fold}.json")
        with open(output_file, "w") as f:
            json.dump(results, f, indent=4)
 
        # Generate report
        total_time = sum(generation_times)
        avg_time = total_time / len(numbers_list) if len(numbers_list) > 0 else 0
        report_content = (
            f"Fold {fold} Evaluation Completed:\n"
            f"Results saved to: {output_file}\n"
            f"Total time: {total_time:.2f} seconds\n"
            f"Average generation time per example: {avg_time:.2f} seconds\n"
            f"Questions evaluated: {len(numbers_list)}\n\n"
        )
        print(report_content)
 
    print(f"All folds completed for finding subtraction task.")
 
 
if __name__ == "__main__":

    if len(sys.argv) < 2:
        print("Usage: python subtraction.py <model_id>")
        sys.exit(1)
 
    model_id = sys.argv[1]
    model_name = model_id.split("/")[-1]
 
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    llm = LLM(
        model=model_id,
        tensor_parallel_size=1,
        max_model_len=8192,
        trust_remote_code=True
    )
 
    sampling_params = SamplingParams(max_tokens=2048)
 
    base_output_dir = model_name
    os.makedirs(base_output_dir, exist_ok=True)
    
    include_negatives = True
    for size in [2]:
        suffix = "positive_only" if not include_negatives else "mixed_numbers"
        task_dir = os.path.join(base_output_dir, f"subtraction_in_{size}_numbers_{suffix}")
        os.makedirs(task_dir, exist_ok=True)

        print(f"Evaluating Subtraction with list size {size} ({'positives only' if not include_negatives else 'mixed'} numbers)...")
        numbers_list = generate_numbers_list(size, include_negatives=include_negatives)

        evaluate_subtraction_task(numbers_list, task_dir, llm, tokenizer, sampling_params)
                
        # Remove model files after evaluations
        model_cache_dir = f"/home/sriramsrinivasan/.cache/huggingface/hub/models--{model_name.replace('/', '--')}"
        print(f"Removing model cache: {model_cache_dir}")
        os.system(f"rm -rf {model_cache_dir}")
    
        print(f"Subtraction evaluations completed for model: {model_id}")
