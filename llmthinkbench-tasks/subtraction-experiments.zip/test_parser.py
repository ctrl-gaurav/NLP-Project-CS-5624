import sys
sys.path.append('/home/sriramsrinivasan/subtraction-experiments')

from parse_response_subtraction import extract_answer_from_response

def test_parser(model_response, prompt=None):
    """
    Test the parser with a model response and optional prompt.
    
    Args:
        model_response (str): The model's response to parse
        prompt (str, optional): The prompt that was given to the model
        
    Returns:
        dict: A dictionary containing the parsing results
    """
    # Call the parser function
    instruction_followed, parsed_difference = extract_answer_from_response(model_response, prompt)
    
    # Debug information about the parsed difference
    parsed_type = type(parsed_difference).__name__
    parsed_value = parsed_difference
    parsed_abs = abs(parsed_difference) if isinstance(parsed_difference, (int, float)) else None
    
    # Create a result dictionary
    result = {
        "model_response": model_response,
        "parsed_difference": parsed_difference,
        "parsed_type": parsed_type,
        "parsed_abs": parsed_abs,
        "instruction_followed": instruction_followed
    }
    
    if prompt:
        result["prompt"] = prompt
    
    return result

def main():
    # Example model response
    model_response = """To subtract -21 from -75, you can think of it as adding the opposite of -21 to -75, which is equivalent to subtracting a negative number and thus adding a positive number. So, the problem can be rephrased as:

-75 + 21

When you add 21 to -75, you move 21 units to the right on the number line from -75. This calculation gives:

-75 + 21 = -54

Therefore, the answer in \\boxed{answer} format is:

\\boxed{-54}"""

    # Example prompt
    prompt = "Can you subtract -21 from -75 and provide your final answer in \\boxed{answer} format at the end of your response."
    
    # Test the parser
    result = test_parser(model_response, prompt)
    
    # Print the results
    print("Model Response:")
    print(model_response)
    print("\nParsing Results:")
    print(f"Parsed Difference: {result['parsed_difference']}")
    print(f"Parsed Type: {result['parsed_type']}")
    print(f"Parsed Abs: {result['parsed_abs']}")
    print(f"Instruction Followed: {result['instruction_followed']}")

if __name__ == "__main__":
    main()
